import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthappService } from './authapp.service';

@Injectable({
  providedIn: 'root'
})
/* https://angular.io/api/router/CanActivate */
export class RouteGuardService implements CanActivate {

  constructor(private Auth:AuthappService, private route: Router) { }

  canActivate(route : ActivatedRouteSnapshot, state : RouterStateSnapshot){
    /*throw new Error ("Method not implemented");*/
    if(!this.Auth.isLogged()){
      this.route.navigate(['login']);
      return false;

    }else{
    return true;
    }

   }

 
}
