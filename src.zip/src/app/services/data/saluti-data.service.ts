import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthappService } from '../authapp.service';

@Injectable({
  providedIn: 'root'
})
export class SalutiDataService {

  private getUrl = '';
 

  constructor(private httpClient:HttpClient, private Auth:AuthappService) { } // ho voluto provare a ricontrollare che sia loggato.


  getSaluti(){ 
    
    if(this.Auth.loggedUser!= null){ 

    this.getUrl='http://localhost:8050/api/saluti/' + this.Auth.loggedUser();

    return this.httpClient.get(this.getUrl);
    //console.log("Saluti");

  }
  }

}
