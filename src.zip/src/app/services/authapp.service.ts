import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthappService {

  constructor() { }


  //funzione di autenticazione
  autentica( UserId, Password){
    if(UserId==='Nicola'&& Password==='123'){
      //https://developer.mozilla.org/it/docs/Web/API/Window/sessionStorage
      sessionStorage.setItem("Utente", UserId);
      return true;
    }else{
      return false;


   }
  }
  loggedUser(){ 
    let utente = sessionStorage.getItem("Utente");
    return (sessionStorage.getItem("Utente") != null) ? utente:"";
  }
  isLogged(){
  return (sessionStorage.getItem("Utente") != null) ? true : false;
 }

 clearSession(){
  
  sessionStorage.removeItem("Utente");
  sessionStorage.clear();
  }
 

}

