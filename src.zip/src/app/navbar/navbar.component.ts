import { Component, OnInit } from '@angular/core';
import { AuthappService } from '../services/authapp.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private Auth:AuthappService) { }

  ngOnInit() {
  }

  /* Codice di controllo Auth nell html cosi da essere aggiornato sempre e non solo quando avvio app. */

}
