import { Component, OnInit } from '@angular/core';
import { NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { AuthappService } from '../services/authapp.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userid=''
  password=''
  autenticato = false
  errorMsg=''

  //consentito = false
  //infoMsg=''

  //CodeInjection : creare una variabile ed indicare il tipo di servizio (AuthApp)
  constructor(private route : Router, private Auth: AuthappService) { }

  ngOnInit() {
  }
 
  gestAut(){

    if(this.Auth.autentica(this.userid, this.password)){
    this.autenticato=true;
    this.route.navigate(['welcome',this.userid]);
  }else{
    this.autenticato=false;
    this.errorMsg='UserID o Password non corretti!';
  }
    /*
    if(this.userid==='Nicola'&& this.password==='123'){
      this.autenticato=true;
      this.route.navigate(['welcome',this.userid]);
      //this.consentito=true;
      //this.infoMsg='Autenticato!'
    }else{
      this.autenticato=false;
      //this.consentito=false;
      this.errorMsg='UserID o Password non corretti!';

    }
    */
    console.log(this.autenticato);
  }
}
