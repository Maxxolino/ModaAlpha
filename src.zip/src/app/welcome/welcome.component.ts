import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SalutiDataService } from '../services/data/saluti-data.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  messaggio =''
  saluti ='Benvenuti in ModaAlpha'
  titolo2='Seleziona gli articoli da acquistare'

  utente =''
  constructor(private route:ActivatedRoute, private salutiSrv:SalutiDataService) { }

  ngOnInit() {

    this.utente=this.route.snapshot.params['userid'];
    
    //console.log(this.messaggio);
  }

  getSaluti(){
    console.log(this.salutiSrv.getSaluti());

    this.salutiSrv.getSaluti().subscribe( // per lanciare la richiesta in maniera asincrona, perchè tra angular e spring tutto asincrono
      response => this.handleResponse(response)
    );
   }

   handleResponse(response){

    this.messaggio = response;

    console.log(response);

   }
  

}
